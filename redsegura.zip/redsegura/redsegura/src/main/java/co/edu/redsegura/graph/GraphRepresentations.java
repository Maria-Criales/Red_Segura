package co.edu.redsegura.graph;

import co.edu.redsegura.model.Edge;

import java.util.ArrayList;
import java.util.List;

/**
 * Lista de adyacencia, matriz de adyacencia ponderada y matriz de incidencia.
 * Todas usan el mismo orden de vertices (orden de insercion) y de conexiones (orden de insercion).
 * Las conexiones bloqueadas no se incluyen.
 * Matriz de adyacencia: O(V^2) espacio. Matriz de incidencia: O(V*E) espacio.
 */
public final class GraphRepresentations {

    private GraphRepresentations() { }

    private static List<Edge> activeEdges(MixedGraph g) {
        List<Edge> list = new ArrayList<>();
        for (Edge e : g.edges()) {
            if (!e.isBlocked()) list.add(e);
        }
        return list;
    }

    public static List<String> activeEdgeIds(MixedGraph g) {
        List<String> ids = new ArrayList<>();
        for (Edge e : activeEdges(g)) ids.add(e.getId());
        return ids;
    }

    public static String adjacencyList(MixedGraph g) {
        StringBuilder sb = new StringBuilder();
        for (String id : g.vertexIds()) {
            sb.append(String.format("%-4s ->", id));
            for (MixedGraph.Step s : g.neighbors(id)) {
                sb.append(' ').append(s.to()).append('(').append(s.edge().getWeight())
                  .append(", ").append(s.edge().getId()).append(')');
            }
            sb.append('\n');
        }
        return sb.toString();
    }

    /** m[i][j] = minutos de i a j; 0 si no hay conexion. Una arista llena ambos sentidos. */
    public static int[][] adjacencyMatrix(MixedGraph g) {
        List<String> ids = g.vertexIds();
        int n = ids.size();
        int[][] m = new int[n][n];
        for (Edge e : activeEdges(g)) {
            int i = ids.indexOf(e.getFrom());
            int j = ids.indexOf(e.getTo());
            put(m, i, j, e.getWeight());
            if (!e.isDirected()) put(m, j, i, e.getWeight());
        }
        return m;
    }

    private static void put(int[][] m, int i, int j, int w) {
        if (m[i][j] == 0 || w < m[i][j]) m[i][j] = w;   // si hay paralelas, queda la menor
    }

    /**
     * Filas = vertices, columnas = conexiones.
     * Arco: -1 en el origen y +1 en el destino. Arista no dirigida: +1 en ambos extremos.
     */
    public static int[][] incidenceMatrix(MixedGraph g) {
        List<String> ids = g.vertexIds();
        List<Edge> es = activeEdges(g);
        int[][] m = new int[ids.size()][es.size()];
        for (int c = 0; c < es.size(); c++) {
            Edge e = es.get(c);
            int i = ids.indexOf(e.getFrom());
            int j = ids.indexOf(e.getTo());
            if (e.isDirected()) {
                m[i][c] = -1;
                m[j][c] = 1;
            } else {
                m[i][c] = 1;
                m[j][c] = 1;
            }
        }
        return m;
    }

    public static String adjacencyMatrixText(MixedGraph g) {
        List<String> ids = g.vertexIds();
        return format(ids, ids, adjacencyMatrix(g), true);
    }

    public static String incidenceMatrixText(MixedGraph g) {
        return format(g.vertexIds(), activeEdgeIds(g), incidenceMatrix(g), false);
    }

    private static String format(List<String> rows, List<String> cols, int[][] m, boolean dashForZero) {
        StringBuilder sb = new StringBuilder(String.format("%-5s", ""));
        for (String c : cols) sb.append(String.format("%4s", c));
        sb.append('\n');
        for (int i = 0; i < rows.size(); i++) {
            sb.append(String.format("%-5s", rows.get(i)));
            for (int j = 0; j < cols.size(); j++) {
                String cell = (dashForZero && m[i][j] == 0) ? "-" : String.valueOf(m[i][j]);
                sb.append(String.format("%4s", cell));
            }
            sb.append('\n');
        }
        return sb.toString();
    }
}
