package co.edu.redsegura.model;

/**
 * Conexion entre dos vertices. Si {@code directed} es true es un arco (origen -> destino);
 * si es false es una arista (se puede recorrer en ambos sentidos).
 * El peso son minutos estimados y debe ser mayor que cero.
 */
public final class Edge {
    private final String id;
    private final String label;
    private final String from;
    private final String to;
    private final int weight;
    private final boolean directed;
    private boolean blocked;

    public Edge(String id, String from, String to, boolean directed, int weight, String label) {
        this.id = Checks.text(id, "El ID de la conexion");
        this.from = Checks.text(from, "El origen");
        this.to = Checks.text(to, "El destino");
        this.label = Checks.text(label, "La etiqueta de la conexion");
        if (weight <= 0) {
            throw new IllegalArgumentException("Peso invalido en " + id + ": debe ser mayor que cero (recibido " + weight + ").");
        }
        this.weight = weight;
        this.directed = directed;
    }

    public String getId() { return id; }
    public String getLabel() { return label; }
    public String getFrom() { return from; }
    public String getTo() { return to; }
    public int getWeight() { return weight; }
    public boolean isDirected() { return directed; }
    public boolean isBlocked() { return blocked; }
    public void setBlocked(boolean blocked) { this.blocked = blocked; }

    @Override
    public String toString() {
        return id + " " + from + (directed ? " -> " : " -- ") + to + " [" + weight + " min, " + label + "]"
                + (blocked ? " BLOQUEADA" : "");
    }
}
