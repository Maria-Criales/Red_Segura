package co.edu.redsegura.model;

/** Lugar de la red (universidad, hospital, terminal...). Inmutable y encapsulado. */
public final class Vertex {
    private final String id;
    private final String label;
    private final String type;

    public Vertex(String id, String label, String type) {
        this.id = Checks.text(id, "El ID del vertice");
        this.label = Checks.text(label, "La etiqueta del vertice");
        this.type = Checks.text(type, "El tipo del vertice");
    }

    public String getId() { return id; }
    public String getLabel() { return label; }
    public String getType() { return type; }

    @Override
    public String toString() { return id + " (" + label + ")"; }
}
