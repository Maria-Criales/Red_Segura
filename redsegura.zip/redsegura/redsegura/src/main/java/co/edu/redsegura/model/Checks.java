package co.edu.redsegura.model;

/** Validaciones comunes del modelo (uso interno del paquete). */
final class Checks {
    private Checks() { }

    static String text(String value, String name) {
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException(name + " no puede ser nulo ni vacio.");
        }
        return value.trim();
    }
}
