package co.edu.redsegura.graph;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

/**
 * Busqueda por anchura con cola y conjunto de visitados. Respeta la orientacion de los arcos.
 * Tiempo O(V + E), espacio O(V).
 */
public final class BreadthFirstSearch {

    /** order: orden de visita; level: distancia en saltos; parent: arbol BFS (la raiz tiene padre null). */
    public record Result(List<String> order, Map<String, Integer> level, Map<String, String> parent) { }

    private BreadthFirstSearch() { }

    public static Result run(MixedGraph g, String start) {
        g.requireVertex(start);
        List<String> order = new ArrayList<>();
        Map<String, Integer> level = new LinkedHashMap<>();
        Map<String, String> parent = new LinkedHashMap<>();
        Set<String> visited = new HashSet<>();
        Queue<String> queue = new ArrayDeque<>();

        visited.add(start);
        level.put(start, 0);
        parent.put(start, null);
        queue.add(start);

        while (!queue.isEmpty()) {
            String u = queue.poll();
            order.add(u);
            for (MixedGraph.Step s : g.neighbors(u)) {
                if (visited.add(s.to())) {
                    level.put(s.to(), level.get(u) + 1);
                    parent.put(s.to(), u);
                    queue.add(s.to());
                }
            }
        }
        return new Result(order, level, parent);
    }
}
