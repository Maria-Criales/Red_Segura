package co.edu.redsegura.core;

import co.edu.redsegura.graph.MixedGraph;
import co.edu.redsegura.model.Edge;
import co.edu.redsegura.model.Vertex;

/** Clase fabrica con el conjunto de datos didactico del parcial (12 lugares, 18 conexiones). */
public final class SampleDataFactory {

    private SampleDataFactory() { }

    public static MixedGraph createGraph() {
        MixedGraph g = new MixedGraph();
        g.addVertex(new Vertex("S01", "UAJS Sede C", "Universidad"));
        g.addVertex(new Vertex("S02", "UAJS Sede E", "Universidad"));
        g.addVertex(new Vertex("S03", "Universidad de Sucre", "Universidad"));
        g.addVertex(new Vertex("S04", "CECAR", "Universidad"));
        g.addVertex(new Vertex("S05", "Hospital Universitario", "Salud"));
        g.addVertex(new Vertex("S06", "Clinica Las Americas", "Salud"));
        g.addVertex(new Vertex("S07", "Estacion Central SETP", "Transporte"));
        g.addVertex(new Vertex("S08", "Terminal de Transporte", "Transporte"));
        g.addVertex(new Vertex("S09", "Parque Santander", "Punto de encuentro"));
        g.addVertex(new Vertex("S10", "Mercado de Sincelejo", "Comercio"));
        g.addVertex(new Vertex("S11", "PEP Argelia", "Paradero"));
        g.addVertex(new Vertex("S12", "Glorieta Sincelejito", "Movilidad"));

        // id, origen, destino, dirigida, minutos, etiqueta
        g.addEdge(new Edge("R01", "S01", "S07", true, 4, "Corredor universitario"));
        g.addEdge(new Edge("R02", "S07", "S01", true, 6, "Retorno por via alterna"));
        g.addEdge(new Edge("R03", "S01", "S09", false, 5, "Corredor peatonal"));
        g.addEdge(new Edge("R04", "S02", "S01", false, 8, "Conexion entre sedes"));
        g.addEdge(new Edge("R05", "S02", "S06", true, 10, "Ruta de atencion"));
        g.addEdge(new Edge("R06", "S06", "S05", true, 4, "Corredor clinico"));
        g.addEdge(new Edge("R07", "S05", "S09", false, 6, "Via hospitalaria"));
        g.addEdge(new Edge("R08", "S09", "S10", false, 3, "Centro historico"));
        g.addEdge(new Edge("R09", "S10", "S08", true, 8, "Salida al terminal"));
        g.addEdge(new Edge("R10", "S08", "S10", true, 9, "Ingreso desde terminal"));
        g.addEdge(new Edge("R11", "S03", "S12", false, 4, "Corredor Puerta Roja"));
        g.addEdge(new Edge("R12", "S12", "S09", false, 7, "Troncal al centro"));
        g.addEdge(new Edge("R13", "S04", "S11", false, 6, "Conexion universitaria"));
        g.addEdge(new Edge("R14", "S11", "S07", true, 8, "Ruta SETP al centro"));
        g.addEdge(new Edge("R15", "S07", "S09", false, 3, "Transferencia central"));
        g.addEdge(new Edge("R16", "S07", "S08", true, 12, "Ruta SETP al terminal"));
        g.addEdge(new Edge("R17", "S09", "S03", true, 7, "Ruta hacia universidad"));
        g.addEdge(new Edge("R18", "S12", "S04", true, 9, "Ruta hacia CECAR"));
        return g;
    }
}
