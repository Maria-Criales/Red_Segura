package co.edu.redsegura.graph;

import co.edu.redsegura.model.Edge;
import co.edu.redsegura.model.Vertex;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Grafo mixto, etiquetado y ponderado: admite aristas (no dirigidas) y arcos (dirigidos).
 * Se guarda una lista de adyacencia: una arista aparece en los dos extremos y un arco solo en su origen.
 * Espacio: O(V + E).
 */
public class MixedGraph {

    /** Movimiento posible desde un vertice: la conexion usada y el vértice al que se llega. */
    public record Step(Edge edge, String to) { }

    private final Map<String, Vertex> vertices = new LinkedHashMap<>();
    private final Map<String, Edge> edges = new LinkedHashMap<>();
    private final Map<String, List<Step>> adjacency = new HashMap<>();

    public void addVertex(Vertex vertex) {
        if (vertex == null) {
            throw new IllegalArgumentException("El vertice no puede ser nulo.");
        }
        if (vertices.containsKey(vertex.getId())) {
            throw new IllegalArgumentException("ID de vertice duplicado: " + vertex.getId());
        }
        vertices.put(vertex.getId(), vertex);
        adjacency.put(vertex.getId(), new ArrayList<>());
    }

    public void addEdge(Edge edge) {
        if (edge == null) {
            throw new IllegalArgumentException("La conexion no puede ser nula.");
        }
        if (edges.containsKey(edge.getId())) {
            throw new IllegalArgumentException("ID de conexion duplicado: " + edge.getId());
        }
        requireVertex(edge.getFrom());
        requireVertex(edge.getTo());
        if (edge.getFrom().equals(edge.getTo())) {
            throw new IllegalArgumentException("No se permiten bucles: " + edge.getId());
        }
        edges.put(edge.getId(), edge);
        adjacency.get(edge.getFrom()).add(new Step(edge, edge.getTo()));
        if (!edge.isDirected()) {
            adjacency.get(edge.getTo()).add(new Step(edge, edge.getFrom()));
        }
    }

    /** Devuelve el vertice o lanza IllegalArgumentException si no existe. */
    public Vertex requireVertex(String id) {
        Vertex v = id == null ? null : vertices.get(id);
        if (v == null) {
            throw new IllegalArgumentException("El vertice no existe: " + id);
        }
        return v;
    }

    public boolean hasVertex(String id) { return id != null && vertices.containsKey(id); }

    public Edge requireEdge(String id) {
        Edge e = id == null ? null : edges.get(id);
        if (e == null) {
            throw new IllegalArgumentException("La conexion no existe: " + id);
        }
        return e;
    }

    /** Movimientos disponibles desde el vertice, sin contar conexiones bloqueadas. */
    public List<Step> neighbors(String id) {
        requireVertex(id);
        List<Step> result = new ArrayList<>();
        for (Step s : adjacency.get(id)) {
            if (!s.edge().isBlocked()) {
                result.add(s);
            }
        }
        return result;
    }

    public void blockEdge(String edgeId) { requireEdge(edgeId).setBlocked(true); }
    public void unblockEdge(String edgeId) { requireEdge(edgeId).setBlocked(false); }

    public Collection<Vertex> vertices() { return Collections.unmodifiableCollection(vertices.values()); }
    public Collection<Edge> edges() { return Collections.unmodifiableCollection(edges.values()); }
    public List<String> vertexIds() { return new ArrayList<>(vertices.keySet()); }
    public int vertexCount() { return vertices.size(); }
    public int edgeCount() { return edges.size(); }
}
