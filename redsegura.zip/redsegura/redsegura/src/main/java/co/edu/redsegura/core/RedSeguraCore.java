package co.edu.redsegura.core;

import co.edu.redsegura.graph.BreadthFirstSearch;
import co.edu.redsegura.graph.DepthFirstSearch;
import co.edu.redsegura.graph.DijkstraSolver;
import co.edu.redsegura.graph.MixedGraph;
import co.edu.redsegura.model.Vertex;
import co.edu.redsegura.tree.AvlTree;
import co.edu.redsegura.tree.BinarySearchTree;

/**
 * Fachada del sistema: une el grafo, el ABB y el AVL. La aplicacion solo habla con esta clase
 * y con los metodos publicos de cada modulo (nunca con campos privados).
 */
public class RedSeguraCore {

    /** Comparacion de busqueda de una etiqueta en ABB y AVL. */
    public record SearchComparison(String label, boolean found, int bstSteps, int avlSteps,
                                   int bstHeight, int avlHeight) { }

    private final MixedGraph graph;
    private final BinarySearchTree<String> bst = new BinarySearchTree<>();
    private final AvlTree<String> avl = new AvlTree<>();

    public RedSeguraCore(MixedGraph graph) {
        if (graph == null) {
            throw new IllegalArgumentException("El grafo no puede ser nulo.");
        }
        this.graph = graph;
        for (Vertex v : graph.vertices()) {      // las etiquetas de los lugares son las claves
            bst.insert(v.getLabel());
            avl.insert(v.getLabel());
        }
    }

    public MixedGraph graph() { return graph; }
    public AvlTree<String> avl() { return avl; }
    public BinarySearchTree<String> bst() { return bst; }

    public String labelOf(String vertexId) { return graph.requireVertex(vertexId).getLabel(); }

    public SearchComparison compareSearch(String label) {
        BinarySearchTree.SearchResult a = bst.search(label);
        BinarySearchTree.SearchResult b = avl.search(label);
        return new SearchComparison(label, a.found() && b.found(), a.steps(), b.steps(),
                bst.height(), avl.height());
    }

    public BreadthFirstSearch.Result bfs(String start) { return BreadthFirstSearch.run(graph, start); }

    public DepthFirstSearch.Result dfs(String start) { return DepthFirstSearch.run(graph, start); }

    public DijkstraSolver.Result shortestRoute(String from, String to) {
        return DijkstraSolver.shortestPath(graph, from, to);
    }

    public void blockConnection(String edgeId) { graph.blockEdge(edgeId); }
    public void unblockConnection(String edgeId) { graph.unblockEdge(edgeId); }
}
