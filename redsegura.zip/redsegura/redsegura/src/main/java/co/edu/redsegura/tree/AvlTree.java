package co.edu.redsegura.tree;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * Arbol AVL: ABB que mantiene |factor de balance| <= 1 con rotaciones LL, RR, LR y RL.
 * factor de balance = altura(izquierdo) - altura(derecho). Altura: null = 0, hoja = 1.
 * Complejidad: insert/search/delete O(log n) en todos los casos; espacio O(n).
 */
public class AvlTree<T extends Comparable<T>> {

    private static final class Node<T> {
        T key;
        Node<T> left;
        Node<T> right;
        int height = 1;
        Node(T key) { this.key = key; }
    }

    private Node<T> root;
    private int size;
    private final List<String> rotationLog = new ArrayList<>();

    public boolean insert(T key) {
        Objects.requireNonNull(key, "La clave no puede ser nula");
        if (contains(key)) {
            return false;
        }
        root = insert(root, key);
        size++;
        return true;
    }

    private Node<T> insert(Node<T> n, T key) {
        if (n == null) {
            return new Node<>(key);
        }
        if (key.compareTo(n.key) < 0) {
            n.left = insert(n.left, key);
        } else {
            n.right = insert(n.right, key);
        }
        return rebalance(n);
    }

    public boolean delete(T key) {
        Objects.requireNonNull(key, "La clave no puede ser nula");
        if (!contains(key)) {
            return false;
        }
        root = delete(root, key);
        size--;
        return true;
    }

    private Node<T> delete(Node<T> n, T key) {
        if (n == null) {
            return null;
        }
        int c = key.compareTo(n.key);
        if (c < 0) {
            n.left = delete(n.left, key);
        } else if (c > 0) {
            n.right = delete(n.right, key);
        } else {
            if (n.left == null) return n.right;
            if (n.right == null) return n.left;
            Node<T> succ = n.right;
            while (succ.left != null) succ = succ.left;
            n.key = succ.key;
            n.right = delete(n.right, succ.key);
        }
        return rebalance(n);
    }

    public BinarySearchTree.SearchResult search(T key) {
        Objects.requireNonNull(key, "La clave no puede ser nula");
        Node<T> cur = root;
        int steps = 0;
        while (cur != null) {
            steps++;
            int c = key.compareTo(cur.key);
            if (c == 0) {
                return new BinarySearchTree.SearchResult(true, steps);
            }
            cur = (c < 0) ? cur.left : cur.right;
        }
        return new BinarySearchTree.SearchResult(false, steps);
    }

    public boolean contains(T key) { return search(key).found(); }

    // ---------- balanceo ----------
    private int h(Node<T> n) { return n == null ? 0 : n.height; }

    private void update(Node<T> n) { n.height = 1 + Math.max(h(n.left), h(n.right)); }

    private int balance(Node<T> n) { return n == null ? 0 : h(n.left) - h(n.right); }

    private Node<T> rebalance(Node<T> n) {
        update(n);
        int b = balance(n);
        if (b > 1) {                                   // pesado a la izquierda
            if (balance(n.left) >= 0) {                // LL: rotacion simple a la derecha
                log("LL", n);
                return rotateRight(n);
            }
            log("LR", n);                              // LR: izquierda sobre el hijo, derecha sobre n
            n.left = rotateLeft(n.left);
            return rotateRight(n);
        }
        if (b < -1) {                                  // pesado a la derecha
            if (balance(n.right) <= 0) {               // RR: rotacion simple a la izquierda
                log("RR", n);
                return rotateLeft(n);
            }
            log("RL", n);                              // RL: derecha sobre el hijo, izquierda sobre n
            n.right = rotateRight(n.right);
            return rotateLeft(n);
        }
        return n;
    }

    private Node<T> rotateRight(Node<T> y) {
        Node<T> x = y.left;
        y.left = x.right;
        x.right = y;
        update(y);
        update(x);
        return x;
    }

    private Node<T> rotateLeft(Node<T> x) {
        Node<T> y = x.right;
        x.right = y.left;
        y.left = x;
        update(x);
        update(y);
        return y;
    }

    private void log(String type, Node<T> n) { rotationLog.add(type + " en nodo " + n.key); }

    // ---------- consultas ----------
    public List<T> inOrder() { List<T> out = new ArrayList<>(); inOrder(root, out); return out; }
    public List<T> preOrder() { List<T> out = new ArrayList<>(); preOrder(root, out); return out; }
    public List<T> postOrder() { List<T> out = new ArrayList<>(); postOrder(root, out); return out; }

    private void inOrder(Node<T> n, List<T> out) {
        if (n == null) return;
        inOrder(n.left, out); out.add(n.key); inOrder(n.right, out);
    }

    private void preOrder(Node<T> n, List<T> out) {
        if (n == null) return;
        out.add(n.key); preOrder(n.left, out); preOrder(n.right, out);
    }

    private void postOrder(Node<T> n, List<T> out) {
        if (n == null) return;
        postOrder(n.left, out); postOrder(n.right, out); out.add(n.key);
    }

    public int height() { return h(root); }
    public int size() { return size; }
    public boolean isEmpty() { return size == 0; }
    public T rootKey() { return root == null ? null : root.key; }

    /** Verifica que todos los nodos cumplan |balance| <= 1 (util en pruebas). */
    public boolean isBalanced() { return isBalanced(root); }

    private boolean isBalanced(Node<T> n) {
        if (n == null) return true;
        return Math.abs(balance(n)) <= 1 && isBalanced(n.left) && isBalanced(n.right);
    }

    /** Rotaciones realizadas desde la creacion o desde el ultimo clearRotationLog(). */
    public List<String> rotationLog() { return Collections.unmodifiableList(rotationLog); }
    public void clearRotationLog() { rotationLog.clear(); }
}
