package co.edu.redsegura.graph;

import co.edu.redsegura.model.Edge;

import java.util.ArrayList;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Busqueda en profundidad recursiva con conjunto de visitados.
 * Tiempo O(V + E), espacio O(V) (pila de recursion incluida).
 */
public final class DepthFirstSearch {

    /** order: orden de visita; hasCycle: se encontro un ciclo alcanzable desde el origen. */
    public record Result(List<String> order, boolean hasCycle) { }

    private DepthFirstSearch() { }

    public static Result run(MixedGraph g, String start) {
        g.requireVertex(start);
        List<String> order = new ArrayList<>();
        boolean[] cycle = {false};
        visit(g, start, null, new HashSet<>(), new HashSet<>(), order, cycle);
        return new Result(order, cycle[0]);
    }

    /**
     * Ciclo = regreso a un vertice que sigue en la pila de recursion. Para no confundir
     * "ir y volver por la misma arista" con un ciclo se ignora la conexion por la que se llego.
     */
    private static void visit(MixedGraph g, String u, String viaEdge, Set<String> visited,
                              Set<String> onStack, List<String> order, boolean[] cycle) {
        visited.add(u);
        onStack.add(u);
        order.add(u);
        for (MixedGraph.Step s : g.neighbors(u)) {
            if (s.edge().getId().equals(viaEdge)) {
                continue;
            }
            if (!visited.contains(s.to())) {
                visit(g, s.to(), s.edge().getId(), visited, onStack, order, cycle);
            } else if (onStack.contains(s.to())) {
                cycle[0] = true;
            }
        }
        onStack.remove(u);
    }

    /** Componentes debilmente conexas: se ignora la orientacion de los arcos. */
    public static List<List<String>> weakComponents(MixedGraph g) {
        Map<String, List<String>> undirected = new HashMap<>();
        for (String id : g.vertexIds()) undirected.put(id, new ArrayList<>());
        for (Edge e : g.edges()) {
            if (e.isBlocked()) continue;
            undirected.get(e.getFrom()).add(e.getTo());
            undirected.get(e.getTo()).add(e.getFrom());
        }
        List<List<String>> components = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (String root : g.vertexIds()) {
            if (seen.contains(root)) continue;
            List<String> comp = new ArrayList<>();
            Deque<String> stack = new ArrayDeque<>();
            stack.push(root);
            seen.add(root);
            while (!stack.isEmpty()) {
                String u = stack.pop();
                comp.add(u);
                for (String v : undirected.get(u)) {
                    if (seen.add(v)) stack.push(v);
                }
            }
            components.add(comp);
        }
        return components;
    }
}
