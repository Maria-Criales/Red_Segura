package co.edu.redsegura;

import co.edu.redsegura.core.RedSeguraCore;
import co.edu.redsegura.core.SampleDataFactory;
import co.edu.redsegura.graph.BreadthFirstSearch;
import co.edu.redsegura.graph.DepthFirstSearch;
import co.edu.redsegura.graph.DijkstraSolver;
import co.edu.redsegura.graph.GraphRepresentations;
import co.edu.redsegura.tree.AvlTree;

import java.util.List;
import java.util.Scanner;

/** Aplicación de consola RedSegura. Ejecutar con --demo para correr Q1..Q7 de una vez. */
public class RedSeguraApplication {

    private final RedSeguraCore core = new RedSeguraCore(SampleDataFactory.createGraph());

    public static void main(String[] args) {
        RedSeguraApplication app = new RedSeguraApplication();
        if (args.length > 0 && args[0].equals("--demo")) {
            app.runAll();
        } else {
            app.menu();
        }
    }

    private void menu() {
        Scanner in = new Scanner(System.in);
        while (true) {
            System.out.println("\n=== RedSegura Sincelejo (datos didacticos de simulacion) ===");
            System.out.println("1) Q1 Buscar en ABB y AVL    5) Q5 Dijkstra S02 -> S08");
            System.out.println("2) Q2 Rotaciones AVL         6) Q6 Bloquear R16 y recalcular");
            System.out.println("3) Q3 Representaciones       7) Q7 Consultar vertice (error controlado)");
            System.out.println("4) Q4 BFS y DFS desde S02    8) Demostracion completa   0) Salir");
            System.out.print("Opcion: ");
            if (!in.hasNextLine()) return;
            String op = in.nextLine().trim();
            switch (op) {
                case "1" -> safe(this::q1);
                case "2" -> safe(this::q2);
                case "3" -> safe(this::q3);
                case "4" -> safe(this::q4);
                case "5" -> safe(this::q5);
                case "6" -> safe(this::q6);
                case "7" -> { System.out.print("ID del vertice: "); String id = in.nextLine().trim(); safe(() -> q7(id)); }
                case "8" -> runAll();
                case "0" -> { System.out.println("Hasta luego."); return; }
                default -> System.out.println("Opcion no valida.");
            }
        }
    }

    private void runAll() {
        safe(this::q1); safe(this::q2); safe(this::q3); safe(this::q4);
        safe(this::q5); safe(this::q6); safe(() -> q7("S99"));
    }

    /** Ningun error de datos debe terminar el programa. */
    private void safe(Runnable action) {
        try {
            action.run();
        } catch (IllegalArgumentException ex) {
            System.out.println("Error controlado: " + ex.getMessage());
        }
    }

    private void title(String t) { System.out.println("\n--- " + t + " ---"); }

    private void q1() {
        title("Q1: buscar 'Hospital Universitario' en ABB y AVL");
        RedSeguraCore.SearchComparison c = core.compareSearch("Hospital Universitario");
        System.out.println("Encontrado: " + c.found());
        System.out.println("ABB: " + c.bstSteps() + " pasos (altura " + c.bstHeight() + ")");
        System.out.println("AVL: " + c.avlSteps() + " pasos (altura " + c.avlHeight() + ")");
    }

    private void q2() {
        title("Q2: las cuatro rotaciones del AVL");
        demoRotation("LL", 30, 20, 10);
        demoRotation("RR", 10, 20, 30);
        demoRotation("LR", 30, 10, 20);
        demoRotation("RL", 10, 30, 20);
    }

    private void demoRotation(String name, int a, int b, int c) {
        AvlTree<Integer> t = new AvlTree<>();
        t.insert(a); t.insert(b); t.insert(c);
        System.out.println(name + ": insertar " + a + ", " + b + ", " + c + " -> " + t.rotationLog()
                + " | raíz=" + t.rootKey() + " preorden=" + t.preOrder() + " balanceado=" + t.isBalanced());
    }

    private void q3() {
        title("Q3: representaciones del grafo");
        System.out.println("Lista de adyacencia (destino(minutos, conexion)):");
        System.out.print(GraphRepresentations.adjacencyList(core.graph()));
        System.out.println("\nMatriz de adyacencia ponderada ('-' = sin conexion):");
        System.out.print(GraphRepresentations.adjacencyMatrixText(core.graph()));
        System.out.println("\nMatriz de incidencia (arco: -1 origen, +1 destino; arista: +1 en ambos):");
        System.out.print(GraphRepresentations.incidenceMatrixText(core.graph()));
    }

    private void q4() {
        title("Q4: BFS y DFS desde S02");
        BreadthFirstSearch.Result bfs = core.bfs("S02");
        DepthFirstSearch.Result dfs = core.dfs("S02");
        System.out.println("BFS: " + bfs.order());
        System.out.println("BFS niveles: " + bfs.level());
        System.out.println("DFS: " + dfs.order() + "  (ciclo detectado: " + dfs.hasCycle() + ")");
        System.out.println("Componentes debiles: " + DepthFirstSearch.weakComponents(core.graph()));
        System.out.println("Por qué difieren: BFS visita por niveles con una cola (primero todos los vecinos),"
                + " DFS se hunde por un camino hasta agotarlo y luego retrocede.");
    }

    private void printRoute(DijkstraSolver.Result r) {
        if (!r.reachable()) {
            System.out.println("No hay ruta de " + r.source() + " a " + r.target());
            return;
        }
        System.out.println("Ruta " + r.source() + " -> " + r.target() + ": " + String.join(", ", r.path())
                + " | costo " + r.distance() + " min");
    }

    private void q5() {
        title("Q5: Dijkstra S02 -> S08");
        DijkstraSolver.Result r = core.shortestRoute("S02", "S08");
        printRoute(r);
        System.out.println("Distancias desde S02: " + r.distances());
    }

    private void q6() {
        title("Q6: bloquear R16 y recalcular");
        DijkstraSolver.Result before = core.shortestRoute("S02", "S08");
        core.blockConnection("R16");
        try {
            DijkstraSolver.Result after = core.shortestRoute("S02", "S08");
            System.out.print("Antes:   "); printRoute(before);
            System.out.print("Despues: "); printRoute(after);
            System.out.println(before.path().equals(after.path())
                    ? "La ruta no cambio."
                    : "La ruta cambio: R16 (S07 -> S08) ya no esta disponible, asi que se llega al terminal"
                      + " por el Mercado (R09). El costo "
                      + (before.distance() == after.distance() ? "se mantiene (había empate de 24 min)."
                                                               : "paso a " + after.distance() + " min."));
        } finally {
            core.unblockConnection("R16");
            System.out.println("(R16 se desbloquea para no afectar las demas consultas)");
        }
    }

    private void q7(String vertexId) {
        title("Q7: consultar vertice '" + vertexId + "'");
        System.out.println("Etiqueta: " + core.labelOf(vertexId));
    }
}
