package co.edu.redsegura.graph;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

/**
 * Ruta minima con Dijkstra (pesos positivos). Usa PriorityQueue con "eliminación perezosa":
 * si al sacar una entrada su distancia ya está desactualizada, se descarta.
 * Tiempo O((V + E) log V), espacio O(V).
 * En empates se conserva el primer camino hallado (relajacion estricta con '<').
 */
public final class DijkstraSolver {

    /** distance = -1 y path vacio si el destino no es alcanzable. distances: todas las distancias desde el origen. */
    public record Result(String source, String target, boolean reachable, int distance,
                         List<String> path, Map<String, Integer> distances) { }

    private record Entry(String id, int dist) { }

    private DijkstraSolver() { }

    public static Result shortestPath(MixedGraph g, String source, String target) {
        g.requireVertex(source);
        g.requireVertex(target);

        Map<String, Integer> dist = new HashMap<>();
        Map<String, String> previous = new HashMap<>();
        for (String id : g.vertexIds()) dist.put(id, Integer.MAX_VALUE);
        dist.put(source, 0);

        PriorityQueue<Entry> pq = new PriorityQueue<>((a, b) -> Integer.compare(a.dist(), b.dist()));
        pq.add(new Entry(source, 0));

        while (!pq.isEmpty()) {
            Entry cur = pq.poll();
            if (cur.dist() > dist.get(cur.id())) {
                continue;                                   // entrada vieja
            }
            for (MixedGraph.Step s : g.neighbors(cur.id())) {
                int candidate = cur.dist() + s.edge().getWeight();
                if (candidate < dist.get(s.to())) {         // relajacion
                    dist.put(s.to(), candidate);
                    previous.put(s.to(), cur.id());
                    pq.add(new Entry(s.to(), candidate));
                }
            }
        }

        Map<String, Integer> shown = new LinkedHashMap<>();
        for (String id : g.vertexIds()) shown.put(id, dist.get(id));

        if (dist.get(target) == Integer.MAX_VALUE) {
            return new Result(source, target, false, -1, List.of(), shown);
        }
        List<String> path = new ArrayList<>();
        for (String at = target; at != null; at = previous.get(at)) path.add(at);
        Collections.reverse(path);
        return new Result(source, target, true, dist.get(target), path, shown);
    }
}
