package co.edu.redsegura.tree;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Arbol binario de busqueda (sin balanceo). Altura: arbol vacio = 0, una hoja = 1.
 * Complejidad: insert/search/delete O(h); h = O(log n) en promedio y O(n) en el peor caso.
 */
public class BinarySearchTree<T extends Comparable<T>> {

    /** Resultado de una busqueda: si se encontro y cuántos nodos se visitaron. */
    public record SearchResult(boolean found, int steps) { }

    private static final class Node<T> {
        T key;
        Node<T> left;
        Node<T> right;
        Node(T key) { this.key = key; }
    }

    private Node<T> root;
    private int size;

    /** Inserta la clave. Devuelve false si ya existía (no se permiten duplicados). */
    public boolean insert(T key) {
        Objects.requireNonNull(key, "La clave no puede ser nula");
        if (root == null) {
            root = new Node<>(key);
            size++;
            return true;
        }
        Node<T> cur = root;
        while (true) {
            int c = key.compareTo(cur.key);
            if (c == 0) {
                return false;
            }
            if (c < 0) {
                if (cur.left == null) { cur.left = new Node<>(key); size++; return true; }
                cur = cur.left;
            } else {
                if (cur.right == null) { cur.right = new Node<>(key); size++; return true; }
                cur = cur.right;
            }
        }
    }

    /** Busca la clave contando los nodos visitados. */
    public SearchResult search(T key) {
        Objects.requireNonNull(key, "La clave no puede ser nula");
        Node<T> cur = root;
        int steps = 0;
        while (cur != null) {
            steps++;
            int c = key.compareTo(cur.key);
            if (c == 0) {
                return new SearchResult(true, steps);
            }
            cur = (c < 0) ? cur.left : cur.right;
        }
        return new SearchResult(false, steps);
    }

    public boolean contains(T key) { return search(key).found(); }

    /** Elimina la clave. Devuelve false si no existia. */
    public boolean delete(T key) {
        if (!contains(key)) {
            return false;
        }
        root = delete(root, key);
        size--;
        return true;
    }

    private Node<T> delete(Node<T> node, T key) {
        if (node == null) {
            return null;
        }
        int c = key.compareTo(node.key);
        if (c < 0) {
            node.left = delete(node.left, key);
        } else if (c > 0) {
            node.right = delete(node.right, key);
        } else {
            if (node.left == null) return node.right;   // 0 o 1 hijo
            if (node.right == null) return node.left;
            Node<T> succ = node.right;                   // 2 hijos: sucesor in-orden
            while (succ.left != null) succ = succ.left;
            node.key = succ.key;
            node.right = delete(node.right, succ.key);
        }
        return node;
    }

    public List<T> inOrder() { List<T> out = new ArrayList<>(); inOrder(root, out); return out; }
    public List<T> preOrder() { List<T> out = new ArrayList<>(); preOrder(root, out); return out; }
    public List<T> postOrder() { List<T> out = new ArrayList<>(); postOrder(root, out); return out; }

    private void inOrder(Node<T> n, List<T> out) {
        if (n == null) return;
        inOrder(n.left, out); out.add(n.key); inOrder(n.right, out);
    }

    private void preOrder(Node<T> n, List<T> out) {
        if (n == null) return;
        out.add(n.key); preOrder(n.left, out); preOrder(n.right, out);
    }

    private void postOrder(Node<T> n, List<T> out) {
        if (n == null) return;
        postOrder(n.left, out); postOrder(n.right, out); out.add(n.key);
    }

    /** Altura en niveles: vacio = 0, hoja = 1. */
    public int height() { return height(root); }

    private int height(Node<T> n) {
        return n == null ? 0 : 1 + Math.max(height(n.left), height(n.right));
    }

    public int size() { return size; }
    public boolean isEmpty() { return size == 0; }
}
