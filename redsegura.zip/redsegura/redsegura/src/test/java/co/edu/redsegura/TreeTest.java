package co.edu.redsegura;

import co.edu.redsegura.tree.AvlTree;
import co.edu.redsegura.tree.BinarySearchTree;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class TreeTest {

    private AvlTree<Integer> avlWith(int... keys) {
        AvlTree<Integer> t = new AvlTree<>();
        for (int k : keys) t.insert(k);
        return t;
    }

    @Test
    void rotacionLL() { AvlTree<Integer> t = avlWith(30, 20, 10); assertEquals(20, t.rootKey()); assertTrue(t.rotationLog().get(0).startsWith("LL")); }

    @Test
    void rotacionRR() { AvlTree<Integer> t = avlWith(10, 20, 30); assertEquals(20, t.rootKey()); assertTrue(t.rotationLog().get(0).startsWith("RR")); }

    @Test
    void rotacionLR() { AvlTree<Integer> t = avlWith(30, 10, 20); assertEquals(20, t.rootKey()); assertTrue(t.rotationLog().get(0).startsWith("LR")); }

    @Test
    void rotacionRL() { AvlTree<Integer> t = avlWith(10, 30, 20); assertEquals(20, t.rootKey()); assertTrue(t.rotationLog().get(0).startsWith("RL")); }

    @Test
    void avlSeMantieneBalanceadoConDatosOrdenados() {
        AvlTree<Integer> t = new AvlTree<>();
        for (int i = 1; i <= 100; i++) t.insert(i);
        assertTrue(t.isBalanced());
        assertTrue(t.height() <= 8);
        for (int i = 1; i <= 100; i += 2) t.delete(i);
        assertTrue(t.isBalanced());
        assertEquals(50, t.size());
    }

    @Test
    void abbSeDegeneraConDatosOrdenados() {
        BinarySearchTree<Integer> t = new BinarySearchTree<>();
        for (int i = 1; i <= 10; i++) t.insert(i);
        assertEquals(10, t.height());
        assertEquals(10, t.search(10).steps());
    }

    @Test
    void abbRecorridosYEliminacion() {
        BinarySearchTree<Integer> t = new BinarySearchTree<>();
        for (int k : new int[]{50, 30, 70, 20, 40, 60, 80}) t.insert(k);
        assertEquals(List.of(20, 30, 40, 50, 60, 70, 80), t.inOrder());
        assertEquals(List.of(50, 30, 20, 40, 70, 60, 80), t.preOrder());
        assertEquals(List.of(20, 40, 30, 60, 80, 70, 50), t.postOrder());
        assertTrue(t.delete(50));
        assertFalse(t.delete(999));
        assertEquals(List.of(20, 30, 40, 60, 70, 80), t.inOrder());
        assertFalse(t.insert(60));   // duplicado
    }
}
