package co.edu.redsegura;

import co.edu.redsegura.core.RedSeguraCore;
import co.edu.redsegura.core.SampleDataFactory;
import co.edu.redsegura.graph.*;
import co.edu.redsegura.model.Edge;
import co.edu.redsegura.model.Vertex;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class GraphTest {

    private MixedGraph g;

    @BeforeEach
    void setUp() { g = SampleDataFactory.createGraph(); }

    @Test
    void datosCargados() {
        assertEquals(12, g.vertexCount());
        assertEquals(18, g.edgeCount());
    }

    @Test
    void dijkstraS02aS08Da24() {
        DijkstraSolver.Result r = DijkstraSolver.shortestPath(g, "S02", "S08");
        assertTrue(r.reachable());
        assertEquals(24, r.distance());
        assertEquals(List.of("S02", "S01", "S07", "S08"), r.path());
    }

    @Test
    void bloquearR16CambiaLaRuta() {
        g.blockEdge("R16");
        DijkstraSolver.Result r = DijkstraSolver.shortestPath(g, "S02", "S08");
        assertEquals(List.of("S02", "S01", "S09", "S10", "S08"), r.path());
        assertEquals(24, r.distance());
    }

    @Test
    void respetaOrientacion() {
        // R16 es dirigida S07 -> S08: de S08 no se llega a S07 por ahí
        assertTrue(g.neighbors("S08").stream().noneMatch(s -> s.to().equals("S07")));
    }

    @Test
    void verticeInexistenteLanzaExcepcion() {
        assertThrows(IllegalArgumentException.class, () -> DijkstraSolver.shortestPath(g, "S99", "S08"));
        assertThrows(IllegalArgumentException.class, () -> BreadthFirstSearch.run(g, "S99"));
        assertThrows(IllegalArgumentException.class, () -> new RedSeguraCore(g).labelOf("S99"));
    }

    @Test
    void grafoDesconectadoNoTieneRuta() {
        MixedGraph h = new MixedGraph();
        h.addVertex(new Vertex("A", "A", "x"));
        h.addVertex(new Vertex("B", "B", "x"));
        DijkstraSolver.Result r = DijkstraSolver.shortestPath(h, "A", "B");
        assertFalse(r.reachable());
        assertEquals(-1, r.distance());
        assertEquals(2, DepthFirstSearch.weakComponents(h).size());
    }

    @Test
    void pesosInvalidos() {
        assertThrows(IllegalArgumentException.class, () -> new Edge("X", "S01", "S02", false, 0, "e"));
        assertThrows(IllegalArgumentException.class, () -> new Edge("X", "S01", "S02", false, -5, "e"));
    }

    @Test
    void duplicadosEInexistentes() {
        assertThrows(IllegalArgumentException.class, () -> g.addVertex(new Vertex("S01", "otro", "x")));
        assertThrows(IllegalArgumentException.class, () -> g.addEdge(new Edge("R01", "S01", "S02", false, 1, "e")));
        assertThrows(IllegalArgumentException.class, () -> g.addEdge(new Edge("R99", "S01", "S77", false, 1, "e")));
    }

    @Test
    void bfsVisitaTodoLoAlcanzable() {
        BreadthFirstSearch.Result r = BreadthFirstSearch.run(g, "S02");
        assertEquals("S02", r.order().get(0));
        assertEquals(0, r.level().get("S02"));
        assertEquals(new java.util.HashSet<>(r.order()).size(), r.order().size()); // sin repetidos
    }

    @Test
    void dfsDetectaCicloYUnaComponente() {
        assertTrue(DepthFirstSearch.run(g, "S02").hasCycle());
        assertEquals(1, DepthFirstSearch.weakComponents(g).size());
    }

    @Test
    void representacionesConsistentes() {
        int[][] adj = GraphRepresentations.adjacencyMatrix(g);
        int[][] inc = GraphRepresentations.incidenceMatrix(g);
        assertEquals(12, adj.length);
        assertEquals(12, inc.length);
        assertEquals(18, inc[0].length);
        int s01 = 0, s07 = 6;
        assertEquals(4, adj[s01][s07]);   // R01 dirigida S01 -> S07
        assertEquals(6, adj[s07][s01]);   // R02 dirigida S07 -> S01
        assertEquals(-1, inc[s01][0]);    // R01: origen -1
        assertEquals(1, inc[s07][0]);     // R01: destino +1
    }
}
